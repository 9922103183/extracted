#include<stdio.h>
int main()
{
int a=10;
int b=20;
if(a<b)
    {
    printf("B is Greater Than A ");   
    }
 else{
     printf("A is Grater than B");
     }
return 0 ;
}