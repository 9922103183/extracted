#include<stdio.h>
int main()
{
int a=10;

if(a<0)
    {
    printf("Number is Negative");   
    }
else if(a>0){
    printf("Number is Positive");
    
 }
 else{
     printf("Number is Zero");
      // Only Remaining case that is  (a=0)
     }
     
return 0 ;
}
