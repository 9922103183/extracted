#include <stdio.h>
int main()
{
    int i;
    i = 1;
      do{
        printf("Hello World\n");
        i++;
        //this loop will print "Hello World " Prompt 10 times
    }while(i !=10);
    return 0;
}