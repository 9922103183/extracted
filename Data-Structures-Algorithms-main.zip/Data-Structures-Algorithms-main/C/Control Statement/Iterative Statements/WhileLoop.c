#include <stdio.h>
int main()
{
    int i;
    i = 1;
    while (i != 10)
    {
        printf("Hello World\n");
        i++;
        //this loop will print "Hello World " Prompt 10 times
    }
    return 0;
}