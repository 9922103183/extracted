#include<stdio.h>
int main()
{
int i ;
for(i=1 ; i<10 ; i++){
    printf("Hello World !!");
    //This Loop will print Hello World Prompt 10 times
    }
return 0 ;
}