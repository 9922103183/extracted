#include <stdio.h>

int main() {
    // Declaring an array of integers with size 5
    int numbers[5];

    // Assigning values to the array elements
    numbers[0] = 10;
    numbers[1] = 20;
    numbers[2] = 30;
    numbers[3] = 40;
    numbers[4] = 50;

    // Accessing and printing array elements
    printf("Element 0: %d\n", numbers[0]);
    printf("Element 1: %d\n", numbers[1]);
    printf("Element 2: %d\n", numbers[2]);
    printf("Element 3: %d\n", numbers[3]);
    printf("Element 4: %d\n", numbers[4]);

    return 0;
}
