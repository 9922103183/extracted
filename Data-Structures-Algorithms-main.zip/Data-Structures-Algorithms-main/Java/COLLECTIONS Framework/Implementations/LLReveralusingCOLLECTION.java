import java.util.Collections;
class LL {
public static void main(String[] args){
LinkedList<Integer> list2 = new LinkedList<>();
       list2.add(1);
       list2.add(2);
       Collections.reverse(list2);
    }
}
