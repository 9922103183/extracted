public class BasicFunction {
    // Method that prints a greeting
    public static void printGreeting() {
        System.out.println("Hello, World!");
    }

    public static void main(String[] args) {
        // Calling the method
        printGreeting();
    }
}
