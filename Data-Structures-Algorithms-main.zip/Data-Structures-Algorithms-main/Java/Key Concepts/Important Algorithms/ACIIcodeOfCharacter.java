public class Ascii {
    public static void main(String[] args) {
        char ch = 'a';
        System.out.println((char)(ch + 1));
    }
}
