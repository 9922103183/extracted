/* 
if Statement Syntax : ------>

if (condition) {
    //block of code

*/

public class JavaIf {
    public static void main(String[] args) {
        String name = "Mohan";
        int Roll = 25;
        if (name == "Mohan" && Roll == 25) {
            System.out.println("Details of Mohan.");
        }
    }
}
