public class ForeachExample {
    public static void main(String[] args) {
        int[] numbers = {1, 2, 3, 4, 5};

        // Using foreach loop to iterate over the array
        for (int number : numbers) {
            System.out.println(number);
          // Output :[ 1 2 3 4 5 ]
        }
    }
}
