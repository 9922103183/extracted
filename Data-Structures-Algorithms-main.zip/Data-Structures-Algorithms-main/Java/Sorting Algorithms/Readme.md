## Note 📝 :

There is a Inbuilt Method for Array Sorting
```Arrays.sort(array);``` in ```Arrays Class``` in  the  ```java.util package```

 ### Basic Syntax

 ```java
import java util.Arrays;
int[] array = new int[size];
array={3,2,1,4,5,7,6};
Arrays.sort(array);
//Sorts the array,changes are done in the original array !
```
### Specs

- **Algorithms used :** Quick Sort.
- **Time Complexity :** O(n*logn)
  
