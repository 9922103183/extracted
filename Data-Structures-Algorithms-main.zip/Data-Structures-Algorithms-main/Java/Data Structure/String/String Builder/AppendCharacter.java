// Append a char
//Append means to add something at the end.

import java.util.*;
public class Strings {
   public static void main(String args[]) {
     StringBuilder sb = new StringBuilder("Tony");
     sb.append(" Stark");
     System.out.println(sb);
         }

    }

